#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<time.h>


int task_no = 0;
char *cmd_name;
char *arguments;
char *path = "/bin/";

struct task {
    int task_id;
    struct task *next;
    int exec_val;
    char *name;
    pid_t *pid;
    time_t start_time;
    time_t end_time;
    char *argument;
};

void add_to_list(struct task **head_ptr, char *name, char *argument){
    struct task *node = (struct task *)malloc(sizeof(struct task));
    node->task_id = task_no;
    node->name = name;
    printf("task No:%d  %s\n", node->task_id, node->name);

    node->argument = argument;
    printf("%s\n", node->argument);

    node->next = *head_ptr;
    *head_ptr = node;
}

void execute(struct task *head_ptr, char *path_name){
    head_ptr->start_time = time(NULL);
    *head_ptr->pid = fork();
    char * argv_list[] = {head_ptr->argument ,(char*)0};
    printf("current running: %s, %s", head_ptr->name, head_ptr->argument);
    head_ptr->exec_val = execvp(head_ptr->name, argv_list);
}


int main(int argc, char **argv) {

    struct task *head = NULL;



    printf("%d\n", argc);

    //initializer
    for(int i =1; i<argc; i++){
        if(strcmp(argv[i], ".") == 0){  //if its is a delimiter continue
            continue;
        }
        cmd_name = argv[i];

        if((strcmp(argv[i+1], ".") == 0)){  //if the cmd has no arguments
            arguments = NULL;
            add_to_list(&head, cmd_name, arguments);
            continue;
        }

        i++;

        while(i<argc && (strcmp(argv[i], ".") != 0)){
            arguments = argv[i];
            add_to_list(&head, cmd_name, arguments);
            i++;
        }
    }
    //initializer

    printf("head: %s\n", head->name);
    char *buf = "/bin/";
    printf("%s\n", buf);
    struct task *current = head;

    char *name = current->name;
    printf("%s\n", name);

    strcat(buf, name);
    printf("%s\n", buf);



    char *current_name;
    char *current_arg = current->argument;


    while(current!=NULL){
        buf = "/bin/";
        printf("%s", buf);

        pid_t pid;

        pid = fork();
        //current->pid = (int *) pid;
        if(pid ==0 ){
            execl("/bin/ls", "ls",current_arg, (char *)0);
        }

    }




    /*
    if(pid == 0){
        char *name = head->name;
        printf("%s", name);
        execl("/bin/ls", name, (char *)0);

        //head->pid = pid;
    }
     */

    wait(NULL);


    while(current!= NULL){
        struct task *next = current->next;
        free(current);
        current = next;

    }

    return 0;
}